## Utility Programs:

#### News_To_Company_Ticker_Sector.scala:
- For each piece of news, extract its related company names, tickers, and sectors accordingly.

#### Dumbo Script:  
- **NewsInforMiner_DumboVersion.scala**
- In NYUHPC Dumbo, the file hierachy in HDFS is:
_[lc3397@login-1-1]_$ hdfs dfs -ls project   
**project/alias2ticker.json**  
**project/alltickers**  
**project/article_till_0721**  




