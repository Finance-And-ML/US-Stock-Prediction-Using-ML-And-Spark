Project Progression Log:

1. Correctly retrieved usable data, i.e., News, Intra-day Stock price data, Alias2ticker.json, etc.
2. NewsInfoMinder*.scala to retrieve usable data from news json file. Arrange data in Spark Dataframe and Dataset. Find matched Tickers for each news.
3. Use ticker, the time news was published, to retrieve stock prices. 
4. Calculate price trend from the retrieved datasets.
5. Match ticker price trend and news as pair of train-able data.
6. Construct and train the model.
